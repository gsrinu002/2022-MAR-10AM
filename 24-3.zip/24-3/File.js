alert('external js is working fine ')


document.getElementsByTagName('h1')[0].innerHTML = 'welcome to sunadh'
document.getElementsByTagName('h1')[0].style.textAlign = 'center'
document.getElementsByTagName('h1')[0].style.color = 'red'
document.getElementsByTagName('h1')[0].style.backgroundColor = 'blue'



